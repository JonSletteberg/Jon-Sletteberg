var searchData=
[
  ['globals_5fcheck_5ffor_5ffloor',['globals_check_for_floor',['../globals_8h.html#a078fc9fb0a8761b4c0dd95f11478c3f1',1,'globals.c']]],
  ['globals_5fupdate_5fcurrent_5ffloor',['globals_update_current_floor',['../globals_8h.html#a2c452af3ccbe40c1a7414abee51cf87a',1,'globals.c']]],
  ['globals_5fupdate_5fprevious_5ffloor',['globals_update_previous_floor',['../globals_8h.html#a54f2a692cc4a1aef70c1c535f17512a7',1,'globals.c']]]
];
