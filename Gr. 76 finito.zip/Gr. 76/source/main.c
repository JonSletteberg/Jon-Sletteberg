#include <stdio.h>
#include <stdlib.h>
#include "hardware.h"
#include "lights.h"
#include "queue.h"
#include "door.h"
#include "globals.h"
#include "stopbutton.h"

void boot_control() {
	int error = hardware_init();
	if (error != 0) {
		fprintf(stderr, "Unable to initialize hardware\n");
		exit(1);
	}
	lights_clear_all_lights();
	while (1) {
		for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
			if (hardware_read_floor_sensor(floor)) {
				hardware_command_movement(HARDWARE_MOVEMENT_STOP);
				hardware_command_floor_indicator_on(floor);
				g_current_floor = floor;
				g_state = IDLE;
				return;
			}
		}
		hardware_command_movement(HARDWARE_MOVEMENT_DOWN);
	}
}

	
void state_handler() {
	
	switch (g_state) {
	case IDLE:
		if (queue_check_for_orders() == 1) {
			printf("%d", queue_find_order_floor());
			printf("\n");
			if ((queue_find_order_floor() > g_last_valid_floor) || ((g_direction_bit==0) && (queue_find_order_floor() == g_last_valid_floor))) {
				g_state = MOVING_UP;
				break;
			}
			else if ((queue_find_order_floor() == g_last_valid_floor) && (globals_check_for_floor())){
				g_state = OPEN;
				break;
			}

			else {
				g_state = MOVING_DOWN;
				break;
			}
			g_previous_state = IDLE;
		}
		break;

	case MOVING_UP:
		hardware_command_door_open(0);
		hardware_command_movement(HARDWARE_MOVEMENT_UP);
		if (globals_check_for_floor()) {
			if ((g_queue[g_current_floor][0]) || (g_queue[g_current_floor][2])) {
				g_state = OPEN;
				g_previous_state = MOVING_UP;
			}
			else if (queue_check_for_order_above(g_current_floor)) {
				g_state = MOVING_UP;
			}
			else {
				g_state = IDLE;
			}
		}
		break;

	case MOVING_DOWN:
		hardware_command_door_open(0);
		hardware_command_movement(HARDWARE_MOVEMENT_DOWN);
		if (globals_check_for_floor()) {
			if ((g_queue[g_current_floor][1]) || (g_queue[g_current_floor][2])) {
				g_state = OPEN;
				g_previous_state = MOVING_DOWN;
			}
			else if (queue_check_for_order_below(g_current_floor)){
				g_state = MOVING_DOWN;
			}
			else {
				g_state = IDLE;
			}
		}
		break;

	case OPEN:
		hardware_command_movement(HARDWARE_MOVEMENT_STOP);
		if(g_door_timer==0){
			door_door_timer_start();
			hardware_command_door_open(1);
		}
		if (door_door_open()){
			g_state = IDLE;
		}
		queue_remove_order_and_light(g_current_floor);
		break;

	case EMERGENCY:
		stopbutton_stop_button();
		if (!(hardware_read_stop_signal())) {
			if (globals_check_for_floor()) {
				g_state = OPEN;
			}
			else {
				g_state = IDLE;
			}
			g_previous_state = EMERGENCY;
			hardware_command_stop_light(0);
		}
		break;
	}
}
			


int main(){
	boot_control();
	while (1) {
		globals_update_current_floor(&g_current_floor);
		globals_update_previous_floor(&g_last_valid_floor, &g_direction_bit);
		hardware_command_floor_indicator_on(g_last_valid_floor);
		if (hardware_read_stop_signal()) {
			g_state = EMERGENCY;
		}
		else {
			queue_update_queue_list_and_set_lights();
		}
		state_handler();
	}
}
