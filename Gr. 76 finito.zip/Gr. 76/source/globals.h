/** @file
  * @brief Different declerations for global variables and functions.
  */


/**
  * @brief Enum class for different elevetor states.
  */
typedef enum {
	IDLE, MOVING_UP, MOVING_DOWN, OPEN, EMERGENCY
}valid_states;


/**
  *@brief 2D-array for queue system.
  */
extern int g_queue[][3];

/**
  *@brief Global variable for current floor. 
  *Goes to -1 between floors or floor number in floors.
  */

extern int g_current_floor;

/**
  *@brief Global variable for last valid floor.
  *Goes to last floor hit.
  */

extern int g_last_valid_floor;


extern int g_direction_bit;
/**
  *@brief Global variable for previous floor.
  *Goes to last position hit and then either adds or removes 0.5 depending on direction we leave floor at. Gives full knowledge of position.
  */

//extern float g_previous_floor;

/**
  *@brief Global variable for door timer. 
  */

extern int g_door_timer;


/**
  *@brief Global state used for elevetor management.
  *Holds current state.
  */

extern valid_states g_state;

/**
  *@brief Global state used for elevetor management.
  *Holds previous state.
  */

extern valid_states g_previous_state;


/**
  *@brief Checks if the elevator is at at floor, return 1 if so.
  * @return Return whether elevator is in a legal floor.
  */
int globals_check_for_floor();

/**
  *@brief Updates the global variable current_floor.
  *@param *p_cf Pointer to global variable current floor.
  */
void globals_update_current_floor(int *p_cf);

/**
  *@brief Updates the global variables last_valid_floor and previous_floor.
  *@param *p_lvf Pointer to global variable last_valid_floor.
  *@param *p_pf Pointer to global variable previous_floor
  */
void globals_update_previous_floor(int *p_lvf, int *p_db);




