#include <stdio.h>
#include <stdlib.h>
#include "hardware.h"
#include "queue.h"
#include "globals.h"

static const int order_types_array[3] ={
	HARDWARE_ORDER_UP, HARDWARE_ORDER_DOWN,HARDWARE_ORDER_INSIDE
};

void queue_update_queue_list_and_set_lights() {
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		for (int order_type = 0; order_type < 3; order_type++) {
			if (hardware_read_order(floor, order_types_array[order_type])) {
				g_queue[floor][order_type] = 1;
				hardware_command_order_light(floor,order_types_array[order_type],1);	
			}
		}
	}
}

int queue_check_for_orders() {
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		for (int order_type = 0; order_type < 3; order_type++) {
			int var=g_queue[floor][order_type];
			if (var == 1) {
				return 1;
			}
		}
	}
	return 0;
}

int queue_find_order_floor() {
	if(g_previous_state == MOVING_UP){
		for (int floor = HARDWARE_NUMBER_OF_FLOORS-1; floor > -1; floor--){
			if (g_queue[floor][2]){
				return floor;
			}
		}
		for (int floor = HARDWARE_NUMBER_OF_FLOORS-1; floor > -1; floor--) {
			for (int order_type = 0; order_type < 2; order_type++) {
				if ((g_queue[floor][order_type])) {				
					return floor;
				}
			}
		}
	}
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++){
		if (g_queue[floor][2]){
			return floor;
		}
	}
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		for (int order_type = 0; order_type < 2; order_type++) {
			if ((g_queue[floor][order_type])) {				
				return floor;
			}
		}
	}
	return 0;
}

void queue_remove_all_orders() {
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		for (int order_type = 0; order_type < 3; order_type++) {
			g_queue[floor][order_type] = 0; 
			hardware_command_order_light(floor, order_types_array[order_type],0);
		}
	}
}

int queue_check_for_order_above(int m_current_floor) {
	for (int floor = m_current_floor + 1; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		for (int order_type = 0; order_type < 2; order_type++) {
			if ((g_queue[floor][order_type])) {
				return 1;
			}
		}
	}
	return 0;
}

int queue_check_for_order_below(int m_current_floor) {
	for (int floor = m_current_floor - 1; floor > -1; floor--) {
		for (int order_type = 0; order_type < 2; order_type++) {
			if (g_queue[floor][order_type]) {
				return 1;
			}
		}
	}
	return 0;
}

void queue_remove_order_and_light(int m_floor) {
	for (int order_type = 0; order_type < 3; order_type++) {
		g_queue[m_floor][order_type] = 0;
		hardware_command_order_light(m_floor, order_types_array[order_type], 0);
	}
}




