/** @file
  * @brief All functions for the queue system. 
  *
  * Baseline for implementation of the logic in state_handler. All neccessary functions.
  */

/** 
  * @brief Updates queue with all pressed buttons and sets the corresponding lights active.
  */

void queue_update_queue_list_and_set_lights();

/** 
  * @brief Checks whether any orders are present in queue.
  * @return Returns 1 if any orders.
  */

int queue_check_for_orders();

/** 
  * @brief Checks which floor next order belongs to.
  * @return Returns ordered floor with logic for choosing best floor.
  */

int queue_find_order_floor();

/** 
  * @brief Sets the entirety of queue to 0.
  */

void queue_remove_all_orders();

/** 
  * @brief Checks for any orders above current_floor.
  * @param m_current_floor Current floor elevator is in.
  * @return Returns 1 if any orders above.
  */

int queue_check_for_order_above(int m_current_floor);

/** 
  * @brief Checks for any orders below current_floor.
  * @param m_current_floor Current floor elevator is in.
  * @return Returns 1 if any orders below.
  */

int queue_check_for_order_below(int m_current_floor);

/** 
  * @brief Removes all orders for a specific floor and sets orderlights low.
  * @param m_floor Floor we want data removed for.
  */


void queue_remove_order_and_light(int m_floor);
