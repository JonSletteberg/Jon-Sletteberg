var searchData=
[
  ['valid_5fstates',['valid_states',['../globals_8h.html#a7ea1ef55078b1729c63213d173ac968b',1,'globals.h']]]
];
