var searchData=
[
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]]
];
