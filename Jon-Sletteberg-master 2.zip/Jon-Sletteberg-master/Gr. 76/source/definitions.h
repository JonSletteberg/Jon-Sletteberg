/** @file
  * @brief Definitions
  *
  * Different declerations for global variables
  */


/**
* @brief Enum class for different elevetor states
*/
typedef enum {
	IDLE, MOVING_UP, MOVING_DOWN, OPEN, EMERGENCY
}valid_states;


/**
*@brief 2D-array for queue system
*/
extern int queue[][3];


/**
*@brief Several global variables used for elevetor management
*/
extern int current_floor;

extern int last_valid_floor;

extern float previous_floor;

extern int door_timer;


/**
*@brief Global states used for elevetor management
*/

extern valid_states state;

extern valid_states previous_state;

int check_for_floor();

void update_current_floor(int *cf);

void update_previous_floor(int *lvf, float *pf);




