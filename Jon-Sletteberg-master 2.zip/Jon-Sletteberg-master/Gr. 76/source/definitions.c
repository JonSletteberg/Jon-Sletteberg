
#include "definitions.h"
#include "hardware.h"

int queue[HARDWARE_NUMBER_OF_FLOORS][3]; 

int current_floor;

int last_valid_floor;

float previous_floor;

int door_timer=0;

valid_states state;

valid_states previous_state;

int check_for_floor() {
	if (!(current_floor == -1)) {
		return 1;
	}
	return 0;
}

void update_current_floor(int *cf) {
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		if (hardware_read_floor_sensor(floor)) {
			*cf = floor;
			break;
		}
		else {
			*cf = -1;
		}
	}
}

void update_previous_floor(int *lvf, float *pf) {
	if (check_for_floor()) {
		for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
			if (hardware_read_floor_sensor(floor)) {
				*lvf = floor;
				*pf = *lvf;
			}
		}
	}
	else {
		if (state == MOVING_UP) {
			*pf = *lvf + 0.5;
		}

		else if (state == MOVING_DOWN) {
			*pf = *lvf - 0.5;
		}
	}
}

