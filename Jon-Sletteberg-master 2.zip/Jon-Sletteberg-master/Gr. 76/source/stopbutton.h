/** @file
  * @brief Definitions
  *
  * Different declerations for global variables
  */

void stop_button();
