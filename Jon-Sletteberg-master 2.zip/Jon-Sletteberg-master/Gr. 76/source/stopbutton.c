#include <stdlib.h>
#include "hardware.h"
#include "door.h"
#include "definitions.h"
#include "queue.h"
#include "lights.h"
#include "stopbutton.h"

void stop_button() {
	hardware_command_stop_light(1);
	hardware_command_movement(HARDWARE_MOVEMENT_STOP);
	remove_all_orders();
	clear_all_lights();
	if (check_for_floor()) {
		hardware_command_door_open(1);
	}
}

