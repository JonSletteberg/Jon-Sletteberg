#include <math.h>
#include <stdio.h>
#include "globals.h"
#include "hardware.h"

int g_queue[HARDWARE_NUMBER_OF_FLOORS][3]; 

int g_current_floor;

int g_last_valid_floor;

int g_direction_bit;

//float g_previous_floor;

int g_door_timer=0;

order_types g_order_type;

valid_states g_state;

valid_states g_previous_state;

int globals_check_for_floor() {
	if (!(g_current_floor == -1)) {
		return 1;
	}
	return 0;
}

void globals_update_current_floor(int *p_cf) {
	for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
		if (hardware_read_floor_sensor(floor)) {
			*p_cf = floor;
			break;
		}
		else {
			*p_cf = -1;
		}
	}
}

void globals_update_previous_floor(int *p_lvf, int *p_db) {
	if (globals_check_for_floor()) {
		for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
			if (hardware_read_floor_sensor(floor)) {
				*p_lvf = floor;
			}
		}
		if (g_state == MOVING_UP) {
			*p_db = 1;
		}

		else if (g_state == MOVING_DOWN) {
			*p_db = 0;
		}
	}
}	

/*void globals_update_previous_floor(int *p_lvf, float *p_pf) {
	if (globals_check_for_floor()) {
		for (int floor = 0; floor < HARDWARE_NUMBER_OF_FLOORS; floor++) {
			if (hardware_read_floor_sensor(floor)) {
				*p_lvf = floor;
				*p_pf = *p_lvf;
			}
		}
	}
	else if (!(fmodf(2.1, 1.0)) == 0) {
		if (g_state == MOVING_UP) {
			*p_pf = *p_lvf + 0.5;
		}

		else if (g_state == MOVING_DOWN) {
			*p_pf = *p_lvf - 0.5;
		}
	}
}
*/
