/** @file
  * @brief Definitions
  *
  * Different declerations for global variables and functions
  */


/**
* @brief Enum class for different elevetor states
*/
typedef enum {
	IDLE, MOVING_UP, MOVING_DOWN, OPEN, EMERGENCY
}valid_states;


/**
*@brief 2D-array for queue system
*/
extern int g_queue[][3];


/**
*@brief Several global variables used for elevetor management
*/
extern int g_current_floor;

extern int g_last_valid_floor;

extern float g_previous_floor;

extern int g_door_timer;


/**
*@brief Global states used for elevetor management
*/

extern valid_states g_state;

extern valid_states g_previous_state;


/**
*@brief Checks if the elevator is at at floor, return 1 if so
*/
int globals_check_for_floor();

/**
*@brief Updates the global variable current_floor
*/
void globals_update_current_floor(int *p_cf);

/**
*@brief Updates the global variable previous_floor
*/
void globals_update_previous_floor(int *p_lvf, float *p_pf);




