/** @file
  * @brief Definitions
  *
  * Different declerations for global variables
  */

void stopbutton_stop_button();
