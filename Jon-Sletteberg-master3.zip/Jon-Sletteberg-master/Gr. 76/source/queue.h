
void queue_update_queue_list_and_set_lights();

int queue_check_for_orders();

float queue_find_order_floor();

void queue_remove_all_orders();

int queue_check_for_order_inside();

int queue_check_for_order_above(int m_current_floor);

int queue_check_for_order_below(int m_current_floor);

int queue_check_for_compatible_order_above(int m_current_floor);

int queue_check_for_compatible_order_below(int m_current_floor);

void queue_remove_order_and_light(int m_floor);
